
# MemeFi Bot
Auto Tap MemeFi Bot  

Join Here : [MemeFiBot](https://t.me/memefi_coin_bot?start=r_692637e52f)


## Installation

Install with python

```bash
 	1.	Download Python 3.10 or higher.
	2.	Install Modules: pip install pytz aiohttp.
	3.	Open the Bot in Telegram desktop (when prompted, open on mobile) > Inspect > Application.
	4.	Session Storage > select the key __telegram_initParams.
	5.	Below, there will be tgwebAppdata > copy all its values (e.g., query_idxxxxxxxxxxxx) FULL COPY!
	6.	Paste into query_id.txt (1 line per account).
```


## Features
- Features:

	•	God Mode (1x Tap Boss dies)
	•	Auto Refresh Token
	•	Auto Use Booster Energy
	•	Auto Use Booster Tap
	•	Auto Change Boss
	•	Auto Total Tap Count
	•	Multi Account
	•	Without Telegram APP_ID



